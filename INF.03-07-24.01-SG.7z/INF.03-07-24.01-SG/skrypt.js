function oblicz() {
    let wynik = document.getElementById("wynik");
    let cena = 0;

    if (document.getElementById('peeling').checked) cena += 45;
    if (document.getElementById('maska').checked) cena += 30;
    if (document.getElementById('masaż').checked) cena += 20;
    if (document.getElementById('makijaż').checked) cena += 50;

    wynik.innerText = "Cena zabiegów: " + cena;
}
